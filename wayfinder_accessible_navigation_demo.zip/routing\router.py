"""Deterministic routing engine for accessible indoor navigation.

This is plain Python (no LLM). The neuro-san CodedTools call into it.

Public API (matches the team contract):
    plan_route(source, destination, profile)      -> dict
    find_nearest(source, facility_type, profile)  -> dict
    resolve_location(text)                        -> dict
Extras for the lift-failure stretch goal:
    set_operational(node_id, operational)
    reset()
"""
from difflib import SequenceMatcher
from typing import Dict
from typing import List
from typing import Optional

import networkx as nx

from routing.graph_loader import load_graph

VALID_PROFILES = {"wheelchair", "step_free", "visually_impaired", "standard"}
STEP_FREE_PROFILES = {"wheelchair", "step_free"}

# Words a user (or the LLM) might say -> node "type" used in graph.json
FACILITY_ALIASES = {
    "accessible toilet": "toilet_accessible",
    "accessible toilets": "toilet_accessible",
    "accessible restroom": "toilet_accessible",
    "disabled toilet": "toilet_accessible",
    "toilet": "toilet_accessible",
    "toilets": "toilet_accessible",
    "restroom": "toilet_accessible",
    "toilet_accessible": "toilet_accessible",
    "prayer room": "prayer_room",
    "prayer": "prayer_room",
    "prayer_room": "prayer_room",
    "emergency exit": "exit",
    "fire exit": "exit",
    "exit": "exit",
    "lift": "lift",
    "elevator": "lift",
    "first aid": "first_aid",
    "first aid room": "first_aid",
    "first_aid": "first_aid",
    "quiet room": "quiet_room",
    "quiet_room": "quiet_room",
    "cafe": "cafe",
    "cafeteria": "cafe",
    "canteen": "cafe",
}


class RouteEngine:
    def __init__(self, graph: Optional[nx.Graph] = None, graph_path=None):
        self._path = graph_path
        self.graph = graph if graph is not None else load_graph(graph_path)

    # ------------------------------------------------------------------ helpers
    def reset(self):
        """Reload the graph from disk (undo set_operational changes)."""
        self.graph = load_graph(self._path)

    def set_operational(self, node_id: str, operational: bool) -> bool:
        """Mark a node (e.g. a lift) in/out of service. Returns False if unknown id."""
        if node_id not in self.graph:
            return False
        self.graph.nodes[node_id]["operational"] = bool(operational)
        return True

    @staticmethod
    def _normalise_profile(profile: Optional[str]) -> str:
        profile = (profile or "standard").strip().lower().replace(" ", "_")
        return profile if profile in VALID_PROFILES else "standard"

    def _usable_graph(self, profile: str) -> nx.Graph:
        """Subgraph a given profile is allowed to use."""
        step_free_only = profile in STEP_FREE_PROFILES
        keep = []
        for node_id, attrs in self.graph.nodes(data=True):
            if not attrs.get("operational", True):
                continue
            if step_free_only and not attrs.get("step_free", True):
                continue
            keep.append(node_id)
        usable = self.graph.subgraph(keep).copy()
        if step_free_only:
            blocked = [
                (u, v) for u, v, a in usable.edges(data=True)
                if not a.get("wheelchair_accessible", True)
            ]
            usable.remove_edges_from(blocked)
        return usable

    def _why_unusable(self, node_id: str, profile: str) -> str:
        attrs = self.graph.nodes[node_id]
        if not attrs.get("operational", True):
            return f"{attrs['name']} is currently out of service."
        if profile in STEP_FREE_PROFILES and not attrs.get("step_free", True):
            return f"{attrs['name']} is not step-free accessible."
        return f"{attrs['name']} cannot be used with the '{profile}' profile."

    def _name(self, node_id: str) -> str:
        return self.graph.nodes[node_id]["name"]

    def _steps(self, path: List[str], profile: str) -> List[str]:
        """Turn a node path into readable directions. Corridor hops are merged."""
        g = self.graph
        steps = [f"Start at {self._name(path[0])}."]
        walked = 0
        for i in range(len(path) - 1):
            u, v = path[i], path[i + 1]
            u_attr, v_attr = g.nodes[u], g.nodes[v]
            dist = g.edges[u, v].get("distance", 0)
            if u_attr["floor"] != v_attr["floor"]:
                # vertical move: lift or stairs
                verb = "Take" if u_attr["type"] == "lift" else "Use"
                steps.append(f"{verb} {u_attr['name']} to Floor {v_attr['floor']}.")
                walked = 0
                continue
            walked += dist
            is_last = i == len(path) - 2
            if v_attr["type"] != "corridor" or is_last:
                text = f"Walk {walked} m to {v_attr['name']}"
                if profile == "visually_impaired" and v_attr.get("landmark"):
                    text += f" (landmark: {v_attr['landmark']})"
                steps.append(text + ".")
                walked = 0
        steps.append(f"You have arrived at {self._name(path[-1])}.")
        return steps

    # -------------------------------------------------------------- public API
    def plan_route(self, source: str, destination: str, profile: str = "standard") -> Dict:
        profile = self._normalise_profile(profile)
        g = self.graph
        for label, node_id in (("source", source), ("destination", destination)):
            if node_id not in g:
                return {"found": False, "route": [], "distance": 0, "steps": [],
                        "reason": f"Unknown {label} '{node_id}'."}

        usable = self._usable_graph(profile)
        for node_id in (source, destination):
            if node_id not in usable:
                result = {"found": False, "route": [], "distance": 0, "steps": [],
                          "reason": self._why_unusable(node_id, profile)}
                alt = self._alternative(source, destination, profile, usable)
                if alt:
                    result.update(alt)
                return result

        try:
            path = nx.dijkstra_path(usable, source, destination, weight="distance")
        except nx.NetworkXNoPath:
            result = {"found": False, "route": [], "distance": 0, "steps": [],
                      "reason": f"No route to {self._name(destination)} is available for the "
                                f"'{profile}' profile right now."}
            alt = self._alternative(source, destination, profile, usable)
            if alt:
                result.update(alt)
            return result

        distance = nx.path_weight(usable, path, weight="distance")
        return {"found": True, "route": path, "distance": distance,
                "steps": self._steps(path, profile), "reason": ""}

    def _alternative(self, source, destination, profile, usable) -> Dict:
        """Nearest reachable node of the same type as the destination."""
        if source not in usable:
            return {}
        dest_type = self.graph.nodes[destination]["type"]
        dist, paths = nx.single_source_dijkstra(usable, source, weight="distance")
        candidates = [n for n in dist
                      if n not in (source, destination) and usable.nodes[n]["type"] == dest_type]
        if not candidates:
            return {}
        best = min(candidates, key=lambda n: dist[n])
        return {"alternative": {"id": best, "name": self._name(best),
                                "route": paths[best], "distance": dist[best],
                                "steps": self._steps(paths[best], profile)}}

    def find_nearest(self, source: str, facility_type: str, profile: str = "standard") -> Dict:
        profile = self._normalise_profile(profile)
        wanted = FACILITY_ALIASES.get((facility_type or "").strip().lower(),
                                      (facility_type or "").strip().lower())
        fail = {"found": False, "target": "", "route": [], "distance": 0, "steps": []}
        if source not in self.graph:
            return {**fail, "reason": f"Unknown source '{source}'."}
        usable = self._usable_graph(profile)
        if source not in usable:
            return {**fail, "reason": self._why_unusable(source, profile)}

        dist, paths = nx.single_source_dijkstra(usable, source, weight="distance")
        candidates = [n for n in dist if usable.nodes[n]["type"] == wanted]
        if not candidates:
            return {**fail, "reason": f"No reachable '{wanted}' found for the '{profile}' profile."}
        best = min(candidates, key=lambda n: dist[n])
        return {"found": True, "target": best, "name": self._name(best),
                "route": paths[best], "distance": dist[best],
                "steps": self._steps(paths[best], profile), "reason": ""}

    def resolve_location(self, text: str, limit: int = 3) -> Dict:
        """Fuzzy-match free text to node ids (e.g. 'neptune room' -> MEETING_NEPTUNE)."""
        query = (text or "").strip().lower()
        if not query:
            return {"matches": []}
        scored = []
        for node_id, attrs in self.graph.nodes(data=True):
            names = [node_id.lower().replace("_", " "), attrs["name"].lower()]
            names += [a.lower() for a in attrs.get("aliases", [])]
            best = 0.0
            for name in names:
                if query == name:
                    score = 1.0
                elif name in query or query in name:
                    score = 0.9 + 0.1 * min(len(name), len(query)) / max(len(name), len(query))
                    score = min(score, 0.99)
                else:
                    score = SequenceMatcher(None, query, name).ratio()
                best = max(best, score)
            if best >= 0.5:
                scored.append({"id": node_id, "name": attrs["name"], "score": round(best, 3)})
        scored.sort(key=lambda m: m["score"], reverse=True)
        return {"matches": scored[:limit]}


# ---- module-level default engine, used by the CodedTools -------------------
_ENGINE: Optional[RouteEngine] = None


def get_engine() -> RouteEngine:
    global _ENGINE
    if _ENGINE is None:
        _ENGINE = RouteEngine()
    return _ENGINE


def plan_route(source, destination, profile="standard"):
    return get_engine().plan_route(source, destination, profile)


def find_nearest(source, facility_type, profile="standard"):
    return get_engine().find_nearest(source, facility_type, profile)


def resolve_location(text):
    return get_engine().resolve_location(text)
