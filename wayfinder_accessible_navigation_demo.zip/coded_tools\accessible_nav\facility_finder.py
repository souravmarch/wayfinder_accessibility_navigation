"""neuro-san CodedTool: find the nearest accessible facility.

HOCON args the LLM should supply:  facility_type, source (optional), profile (optional)
facility_type examples: "accessible toilet", "prayer room", "emergency exit", "lift",
                        "first aid", "quiet room", "cafe"
"""
from typing import Any
from typing import Dict

from neuro_san.interfaces.coded_tool import CodedTool
from routing.router import find_nearest


class FacilityFinder(CodedTool):
    """Wraps routing.router.find_nearest."""

    async def async_invoke(self, args: Dict[str, Any], sly_data: Dict[str, Any]) -> Any:
        source = args.get("source") or sly_data.get("current_location")
        facility_type = args.get("facility_type")
        profile = args.get("profile") or sly_data.get("profile") or "standard"

        if not source or not facility_type:
            return {"found": False, "target": "", "route": [], "distance": 0, "steps": [],
                    "reason": "A facility type and a current location are required."}

        result = find_nearest(source, facility_type, profile)
        sly_data["route"] = result.get("route", [])
        sly_data["route_found"] = result.get("found", False)
        return result
