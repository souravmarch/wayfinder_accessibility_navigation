"""Fill in your floor plan in Excel, then convert to graph.json.

    python -m routing.csv_tools export      # graph.json -> data/nodes.csv + data/edges.csv (templates)
    python -m routing.csv_tools build       # data/nodes.csv + data/edges.csv -> data/graph.json

nodes.csv columns: id,name,type,floor,step_free,operational,x,y,aliases,landmark
    aliases are separated by a pipe:  front desk|welcome desk
    step_free / operational: TRUE or FALSE
edges.csv columns: from,to,distance,wheelchair_accessible
"""
import csv
import json
import sys
from pathlib import Path

DATA = Path(__file__).resolve().parent.parent / "data"
NODE_COLS = ["id", "name", "type", "floor", "step_free", "operational", "x", "y", "aliases", "landmark"]
EDGE_COLS = ["from", "to", "distance", "wheelchair_accessible"]


def _bool(text, default=True):
    text = (text or "").strip().lower()
    if not text:
        return default
    return text in {"true", "yes", "1", "y"}


def _num(text):
    text = (text or "").strip()
    if not text:
        return None
    value = float(text)
    return int(value) if value.is_integer() else value


def export_csv():
    data = json.loads((DATA / "graph.json").read_text(encoding="utf-8"))
    with open(DATA / "nodes.csv", "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=NODE_COLS)
        writer.writeheader()
        for n in data["nodes"]:
            writer.writerow({
                "id": n["id"], "name": n["name"], "type": n["type"], "floor": n["floor"],
                "step_free": str(n.get("step_free", True)).upper(),
                "operational": str(n.get("operational", True)).upper(),
                "x": n.get("x", ""), "y": n.get("y", ""),
                "aliases": "|".join(n.get("aliases", [])), "landmark": n.get("landmark", ""),
            })
    with open(DATA / "edges.csv", "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=EDGE_COLS)
        writer.writeheader()
        for e in data["edges"]:
            writer.writerow({"from": e["from"], "to": e["to"], "distance": e["distance"],
                             "wheelchair_accessible": str(e.get("wheelchair_accessible", True)).upper()})
    print("Wrote data/nodes.csv and data/edges.csv")


def build_json():
    nodes, edges = [], []
    # utf-8-sig tolerates the BOM that Excel adds when saving "CSV UTF-8"
    with open(DATA / "nodes.csv", newline="", encoding="utf-8-sig") as handle:
        for row in csv.DictReader(handle):
            if not row["id"].strip():
                continue
            node = {"id": row["id"].strip(), "name": row["name"].strip(), "type": row["type"].strip(),
                    "floor": _num(row["floor"]), "step_free": _bool(row["step_free"]),
                    "operational": _bool(row["operational"])}
            if _num(row["x"]) is not None:
                node["x"], node["y"] = _num(row["x"]), _num(row["y"])
            aliases = [a.strip() for a in (row["aliases"] or "").split("|") if a.strip()]
            if aliases:
                node["aliases"] = aliases
            if (row["landmark"] or "").strip():
                node["landmark"] = row["landmark"].strip()
            nodes.append(node)
    with open(DATA / "edges.csv", newline="", encoding="utf-8-sig") as handle:
        for row in csv.DictReader(handle):
            if not row["from"].strip():
                continue
            edges.append({"from": row["from"].strip(), "to": row["to"].strip(),
                          "distance": _num(row["distance"]),
                          "wheelchair_accessible": _bool(row["wheelchair_accessible"])})
    (DATA / "graph.json").write_text(json.dumps({"nodes": nodes, "edges": edges}, indent=2),
                                     encoding="utf-8")
    print(f"Wrote data/graph.json ({len(nodes)} nodes, {len(edges)} edges). "
          f"Now run: python -m routing.validate_graph")


if __name__ == "__main__":
    command = sys.argv[1] if len(sys.argv) > 1 else ""
    if command == "export":
        export_csv()
    elif command == "build":
        build_json()
    else:
        print(__doc__)
