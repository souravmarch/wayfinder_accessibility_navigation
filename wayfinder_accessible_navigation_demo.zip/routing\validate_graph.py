"""Check graph.json for mistakes. Run:  python -m routing.validate_graph [path]

Exits with code 1 if any ERROR is found (warnings do not fail).
"""
import json
import sys
from pathlib import Path

import networkx as nx

from routing.graph_loader import DEFAULT_GRAPH_PATH
from routing.graph_loader import load_graph

ALLOWED_TYPES = {
    "room", "meeting_room", "toilet_accessible", "lift", "stairs", "ramp", "corridor",
    "exit", "prayer_room", "first_aid", "quiet_room", "cafe",
}


def validate(path=None):
    path = Path(path) if path else DEFAULT_GRAPH_PATH
    errors, warnings = [], []
    with open(path, encoding="utf-8") as handle:
        raw = json.load(handle)

    ids = [n["id"] for n in raw["nodes"]]
    for dup in {i for i in ids if ids.count(i) > 1}:
        errors.append(f"Duplicate node id: {dup}")
    id_set = set(ids)

    for n in raw["nodes"]:
        if n.get("type") not in ALLOWED_TYPES:
            errors.append(f"{n['id']}: type '{n.get('type')}' not in {sorted(ALLOWED_TYPES)}")
        if "floor" not in n:
            errors.append(f"{n['id']}: missing 'floor'")
        if n.get("type") == "stairs" and n.get("step_free", True):
            warnings.append(f"{n['id']}: stairs should have step_free=false")

    for e in raw["edges"]:
        for end in ("from", "to"):
            if e[end] not in id_set:
                errors.append(f"Edge {e['from']}->{e['to']}: unknown node '{e[end]}'")
        if not isinstance(e.get("distance"), (int, float)) or e["distance"] <= 0:
            errors.append(f"Edge {e['from']}->{e['to']}: distance must be a positive number")

    if errors:
        return errors, warnings

    graph = load_graph(path)
    for node_id in graph.nodes:
        if graph.degree(node_id) == 0:
            errors.append(f"Orphan node (no edges): {node_id}")
    if not nx.is_connected(graph):
        parts = [sorted(c) for c in nx.connected_components(graph)]
        errors.append(f"Graph is split into {len(parts)} disconnected parts: {parts}")

    # Every step-free node must be reachable from some step-free node over accessible edges.
    accessible = nx.Graph()
    accessible.add_nodes_from(n for n, a in graph.nodes(data=True) if a["step_free"])
    accessible.add_edges_from(
        (u, v) for u, v, a in graph.edges(data=True)
        if a["wheelchair_accessible"] and graph.nodes[u]["step_free"] and graph.nodes[v]["step_free"]
    )
    main = max(nx.connected_components(accessible), key=len)
    for node_id in accessible.nodes:
        if node_id not in main:
            warnings.append(f"{node_id} is marked step-free but unreachable by wheelchair "
                            f"(check its edges' wheelchair_accessible flags)")
    return errors, warnings


if __name__ == "__main__":
    errs, warns = validate(sys.argv[1] if len(sys.argv) > 1 else None)
    for w in warns:
        print("WARNING:", w)
    for e in errs:
        print("ERROR:  ", e)
    if errs:
        sys.exit(1)
    print("graph.json is valid.")
