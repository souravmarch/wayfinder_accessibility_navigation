"""Try the router from a terminal (no LLM needed).

Examples (run from the project root):
    python -m routing.cli route RECEPTION MEETING_NEPTUNE wheelchair
    python -m routing.cli route RECEPTION ROOM_301 wheelchair
    python -m routing.cli nearest RECEPTION "accessible toilet" wheelchair
    python -m routing.cli resolve "neptune room"
    python -m routing.cli route RECEPTION MEETING_NEPTUNE wheelchair --lift-down LIFT_A_F1
"""
import argparse
import json

from routing.router import RouteEngine


def main():
    parser = argparse.ArgumentParser(description="Accessible navigation router")
    parser.add_argument("command", choices=["route", "nearest", "resolve"])
    parser.add_argument("args", nargs="+")
    parser.add_argument("--lift-down", action="append", default=[],
                        help="node id to mark out of service (repeatable)")
    options = parser.parse_args()

    engine = RouteEngine()
    for node_id in options.lift_down:
        engine.set_operational(node_id, False)

    if options.command == "route":
        source, destination = options.args[0], options.args[1]
        profile = options.args[2] if len(options.args) > 2 else "standard"
        result = engine.plan_route(source, destination, profile)
    elif options.command == "nearest":
        source, facility = options.args[0], options.args[1]
        profile = options.args[2] if len(options.args) > 2 else "standard"
        result = engine.find_nearest(source, facility, profile)
    else:
        result = engine.resolve_location(" ".join(options.args))

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
