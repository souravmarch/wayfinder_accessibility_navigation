# Wayfinder Accessible Navigation Demo

This package runs the complete local demo: a Neuro-SAN navigation backend, the deterministic indoor routing
tools, and the browser UI with route sharing. It is a hackathon demonstration using fictional sample building data,
not a production navigation service.

## Requirements

- Windows 10 or 11 with PowerShell
- Python 3.12 or newer
- [uv](https://docs.astral.sh/uv/)
- Node.js 20 or newer (includes npm)
- An API key for the LLM provider selected in `config/llm_config.hocon`

The checked-in `config/llm_config.hocon` selects OpenAI. Use an OpenAI API key below, or change that include to
`openrouter_llm_config.hocon` and provide an OpenRouter API key instead. API keys are not included in the ZIP.

## 1. Extract the ZIP

Extract the ZIP to a folder with a path that does not contain unusual shell characters. Open PowerShell in the
extracted project root, the folder containing `requirements.txt`, `registries`, and `apps`.

## 2. Create the Python environment

Run once from the project root:

```powershell
uv venv --python 3.12 .venv
uv pip install --python .venv\Scripts\python.exe -r requirements.txt
```

The install may take several minutes. Keep the `.venv` directory; it is local to the extracted copy and is not
included in the ZIP.

## 3. Add the LLM API key

Create a file named `.env` in the project root, for example by running:

```powershell
notepad .env
```

Add the key matching the provider in `config/llm_config.hocon`, then save and close the file:

```text
OPENAI_API_KEY=your_openai_api_key
```

For OpenRouter, switch the include in `config/llm_config.hocon` to `openrouter_llm_config.hocon` and use:

```text
OPENROUTER_API_KEY=your_openrouter_api_key
```

Never put a real API key in a shared ZIP, source file, screenshot, or chat. The Neuro-SAN CLI loads `.env` from the
project root when it starts.

## 4. Start the Neuro-SAN backend

Open a PowerShell window in the project root and run:

```powershell
& .\.venv\Scripts\python.exe -m neuro_san_studio run --server-only --server-host 127.0.0.1 --server-http-port 8080
```

Leave this window running. Wait for the server startup messages before continuing. In another PowerShell window,
verify the local backend responds:

```powershell
Invoke-RestMethod http://127.0.0.1:8080/api/v1/list
```

Do not expose port `8080` to the LAN or the internet. The browser server proxies requests to this backend.

## 5. Start the Wayfinder web app and phone sharing

Phone QR sharing uses HTTP for this demo, so use it only on a trusted private Wi-Fi network with fictional,
non-sensitive data. The server binds to one private IPv4 address; it does not bind to every interface.

Find the computer's Wi-Fi IPv4 address with `ipconfig`. Use the address of the adapter connected to the same trusted
Wi-Fi network as the phone. In a third PowerShell window, run the following, replacing the example IP with that
address:

```powershell
Set-Location .\apps\accessible_nav_frontend
npm ci
$env:HOST = "192.168.1.152"
$env:PORT = "4174"
$env:NAV_API_TARGET = "http://127.0.0.1:8080"
$env:WAYFINDER_DEMO_LAN = "true"
$env:WAYFINDER_SHARE_ORIGIN = "http://192.168.1.152:4174"
node .\server.js
```

The `HOST` and `WAYFINDER_SHARE_ORIGIN` IP addresses must be identical. Keep this window running. The first `npm ci`
downloads the QR-code dependency from the lockfile.

Open `http://192.168.1.152:4174/` on the computer, replacing the example IP with the same Wi-Fi address. To use the
QR code, connect the phone to that same Wi-Fi and scan the code after generating a route. Confirm that the route
page opens on the phone; a QR image loading in a desktop browser does not prove that the phone can reach the host.

If Windows Firewall blocks the phone, ask an administrator to allow inbound TCP port `4174` from the local subnet
on a trusted private network only. Do not open port `8080`. Guest Wi-Fi, router client isolation, or a Public
network profile may prevent device-to-device connections.

### Run on this computer only

For a loopback-only session without phone sharing, start the frontend with `HOST` set to `127.0.0.1` and open
`http://127.0.0.1:4174/`. Do not set `WAYFINDER_DEMO_LAN` or an HTTP `WAYFINDER_SHARE_ORIGIN`; QR phone sharing
requires the private-LAN opt-in described above or an HTTPS origin.

## 6. Try a route

1. Choose a destination or enter a request such as “I'm at Reception. Find a step-free route to Meeting Room
   Neptune.”
2. Wait for the agent response and confirmed route to appear.
3. Select **Share route** to display the QR code and accessible route link.
4. Scan the QR code using a phone on the same Wi-Fi. The shared page provides written directions and spoken
   guidance controls.

The building graph is the fictional sample in `data/graph.json`. The map does not track a person's live position.
This is **not an evacuation system**; in an emergency, follow official fire procedures and building staff
instructions.

## Stop the demo

Press `Ctrl+C` in the frontend and backend PowerShell windows. To remove the local API key, delete the `.env` file
from the extracted project folder.

## Troubleshooting

- **Backend does not start or reports an LLM authentication error:** Confirm the key is in the project-root `.env`
  and matches the provider include in `config/llm_config.hocon`.
- **The web app reports that the backend is unavailable:** Start the backend first and confirm port `8080` responds
  at `http://127.0.0.1:8080/api/v1/list`.
- **The frontend rejects its host:** `HOST` must be a private IPv4 address and `WAYFINDER_DEMO_LAN` must be
  exactly `true` for LAN mode.
- **Phone sharing is unavailable:** `WAYFINDER_SHARE_ORIGIN` must exactly match the frontend's HTTP scheme, IP, and
  port, for example `http://192.168.1.152:4174`.
- **The QR scans but the page does not load:** Check that the phone is on the same Wi-Fi, that the computer's IP
  has not changed, and that the local firewall permits port `4174` from that subnet. Do not expose the backend
  port.
- **A port is already in use:** Stop the earlier process with `Ctrl+C`, or choose another port and update both
  `PORT` and the port in `WAYFINDER_SHARE_ORIGIN` to the same value.

## ZIP contents and exclusions

The shareable ZIP contains the application and runtime source needed by the demo, including the Neuro-SAN package,
registries, coded tools, routing graph, frontend files, and this README. It intentionally excludes `.env`, virtual
environments, `node_modules`, logs, caches, compiled Python files, local databases, tests, unrelated documentation,
Git history, and previous handoff ZIPs. Python and Node dependencies are restored from `requirements.txt` and
`package-lock.json`.
