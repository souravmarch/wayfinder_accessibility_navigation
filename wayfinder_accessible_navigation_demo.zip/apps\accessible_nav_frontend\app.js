const API_PATH = '/api/v1/accessible_nav/streaming_chat';
const ROUTE_LINE = /^Map route:\s*(.*?)\s*$/gim;
const graphUrl = '/data/graph.json';

const elements = {
  canvas: document.querySelector('#floor-map'),
  tabs: document.querySelector('#floor-tabs'),
  empty: document.querySelector('#map-empty'),
  status: document.querySelector('#map-status'),
  count: document.querySelector('#map-count'),
  locations: document.querySelector('#location-select'),
  profile: document.querySelector('#profile-select'),
  form: document.querySelector('#prompt-form'),
  prompt: document.querySelector('#prompt'),
  conversation: document.querySelector('#conversation'),
  connection: document.querySelector('#connection-state'),
  send: document.querySelector('.send-button'),
  voiceInput: document.querySelector('#voice-input'),
  readAloud: document.querySelector('#read-aloud'),
  voiceStatus: document.querySelector('#voice-status'),
  stopChat: document.querySelector('#stop-chat'),
  shareRoute: document.querySelector('#share-route'),
  shareDialog: document.querySelector('#share-dialog'),
  routeQr: document.querySelector('#route-qr'),
  accessibleRouteLink: document.querySelector('#accessible-route-link'),
  shareHelp: document.querySelector('.share-help'),
  shareStatus: document.querySelector('#share-status'),
  copyRouteLink: document.querySelector('#copy-route-link'),
  shareRouteLink: document.querySelector('#share-route-link'),
  sharedGuidance: document.querySelector('#shared-guidance'),
  sharedGuidanceTitle: document.querySelector('#shared-guidance-title'),
  sharedDirections: document.querySelector('#shared-directions'),
  sharedReadAloud: document.querySelector('#shared-read-aloud'),
  sharedGuideStatus: document.querySelector('#shared-guide-status'),
  mapDescription: document.querySelector('#map-description'),
  networkStatus: document.querySelector('#network-live-status'),
  networkActivity: document.querySelector('#network-activity'),
  networkFlow: document.querySelector('.network-flow'),
};

const SpeechRecognitionApi = window.SpeechRecognition || window.webkitSpeechRecognition;
const AGENT_LABELS = {
  accessible_navigation_assistant: 'Front Man',
  accessibility_agent: 'Accessibility agent',
  location_agent: 'Location agent',
  route_agent: 'Route agent',
  facility_agent: 'Facility agent',
  voice_agent: 'Voice agent',
};

let graph;
let currentFloor;
let confirmedRoute = [];
let chatContext = {};
let lastAssistantText = '';
let speechRecognition;
let speechUtterance;
let busy = false;
let activeRequestController;
let requestId = 0;
let sharedRouteMode = false;
let specialistActivitySeen = false;

function addMessage(kind, text) {
  const wrapper = document.createElement('div');
  wrapper.className = `message ${kind}`;
  const bubble = document.createElement('div');
  bubble.className = 'message-bubble';
  bubble.textContent = text;
  wrapper.append(bubble);
  elements.conversation.append(wrapper);
  elements.conversation.scrollTop = elements.conversation.scrollHeight;
}

function floors() {
  return [...new Set(graph.nodes.map(node => node.floor))].sort((left, right) => Number(left) - Number(right));
}

function setFloor(floor) {
  currentFloor = floor;
  elements.tabs.replaceChildren();
  for (const value of floors()) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'floor-tab';
    button.setAttribute('role', 'tab');
    button.setAttribute('aria-selected', String(value === floor));
    button.tabIndex = value === floor ? 0 : -1;
    button.textContent = `Floor ${value}`;
    button.addEventListener('click', () => setFloor(value));
    button.addEventListener('keydown', event => {
      const floorValues = floors();
      const currentIndex = floorValues.indexOf(value);
      const nextIndex = event.key === 'ArrowRight' || event.key === 'ArrowDown'
        ? (currentIndex + 1) % floorValues.length
        : event.key === 'ArrowLeft' || event.key === 'ArrowUp'
          ? (currentIndex - 1 + floorValues.length) % floorValues.length
          : event.key === 'Home'
            ? 0
            : event.key === 'End'
              ? floorValues.length - 1
              : -1;
      if (nextIndex < 0) return;
      event.preventDefault();
      const nextFloor = floorValues[nextIndex];
      setFloor(nextFloor);
      elements.tabs.querySelector('[aria-selected="true"]')?.focus();
    });
    elements.tabs.append(button);
  }
  drawMap();
}

function locationName(id) {
  return graph.nodes.find(node => node.id === id)?.name || id;
}

function populateLocations() {
  elements.locations.replaceChildren();
  for (const node of graph.nodes.filter(item => !['corridor', 'stairs'].includes(item.type))) {
    const option = document.createElement('option');
    option.value = node.id;
    option.textContent = `${node.name} · F${node.floor}`;
    elements.locations.append(option);
  }
  elements.locations.value = graph.nodes.some(node => node.id === 'RECEPTION') ? 'RECEPTION' : graph.nodes[0].id;
}

function drawMap() {
  const canvas = elements.canvas;
  const bounds = canvas.getBoundingClientRect();
  if (!bounds.width || !bounds.height || !graph) return;
  const scale = window.devicePixelRatio || 1;
  canvas.width = Math.round(bounds.width * scale);
  canvas.height = Math.round(bounds.height * scale);
  const ctx = canvas.getContext('2d');
  ctx.scale(scale, scale);
  const width = bounds.width;
  const height = bounds.height;
  ctx.clearRect(0, 0, width, height);

  const nodes = graph.nodes.filter(node => node.floor === currentFloor && Number.isFinite(node.x) && Number.isFinite(node.y));
  const floorPlaceNames = nodes.map(node => node.name).join(', ');
  const routeDescription = confirmedRoute.length > 1
    ? ` Confirmed route: ${confirmedRoute.map(locationName).join(' to ')}.`
    : ` Selected starting point: ${locationName(elements.locations.value)}.`;
  elements.mapDescription.textContent = `Floor ${currentFloor} diagram. Places shown: ${floorPlaceNames}.${routeDescription} The map is a visual overview; read the written directions for navigation.`;
  if (!nodes.length) {
    ctx.fillStyle = '#58675e';
    ctx.font = '12px Manrope, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('No coordinates available for this floor.', width / 2, height / 2);
    return;
  }
  const minX = Math.min(...nodes.map(node => node.x));
  const maxX = Math.max(...nodes.map(node => node.x));
  const minY = Math.min(...nodes.map(node => node.y));
  const maxY = Math.max(...nodes.map(node => node.y));
  const pad = { x: 86, y: 70 };
  const project = node => ({
    x: pad.x + (maxX === minX ? .5 : (node.x - minX) / (maxX - minX)) * Math.max(1, width - pad.x * 2),
    y: pad.y + (maxY === minY ? .5 : (node.y - minY) / (maxY - minY)) * Math.max(1, height - pad.y * 2),
  });
  const nodeById = new Map(nodes.map(node => [node.id, node]));

  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.lineWidth = 9;
  ctx.strokeStyle = 'rgba(255,255,255,.88)';
  for (const edge of graph.edges) {
    const first = nodeById.get(edge.from);
    const second = nodeById.get(edge.to);
    if (!first || !second) continue;
    const a = project(first);
    const b = project(second);
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
  }

  ctx.lineWidth = 3;
  ctx.strokeStyle = '#bdcbbf';
  for (const edge of graph.edges) {
    const first = nodeById.get(edge.from);
    const second = nodeById.get(edge.to);
    if (!first || !second) continue;
    const a = project(first);
    const b = project(second);
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
  }

  if (confirmedRoute.length > 1) {
    const routeEdges = new Set(confirmedRoute.slice(1).map((id, index) => [confirmedRoute[index], id].sort().join('|')));
    ctx.strokeStyle = 'rgba(40,99,78,.18)';
    ctx.lineWidth = 13;
    for (const edge of graph.edges) {
      if (!routeEdges.has([edge.from, edge.to].sort().join('|'))) continue;
      const first = nodeById.get(edge.from);
      const second = nodeById.get(edge.to);
      if (!first || !second) continue;
      const a = project(first);
      const b = project(second);
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
    }
    ctx.strokeStyle = '#28634e';
    ctx.lineWidth = 6;
    for (const edge of graph.edges) {
      if (!routeEdges.has([edge.from, edge.to].sort().join('|'))) continue;
      const first = nodeById.get(edge.from);
      const second = nodeById.get(edge.to);
      if (!first || !second) continue;
      const a = project(first);
      const b = project(second);
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
    }
  }

  for (const node of nodes) {
    const point = project(node);
    const isStart = node.id === (confirmedRoute[0] || elements.locations.value);
    const isDestination = confirmedRoute.length > 1 && node.id === confirmedRoute.at(-1);
    const isRouteNode = confirmedRoute.includes(node.id);
    const size = isRouteNode ? 10 : node.type === 'corridor' ? 5 : 8;
    const label = node.type === 'corridor' ? `↔ ${node.name}` : node.name;
    const markerColor = isStart ? '#386c9a' : isDestination ? '#b84c3f' : '#fff';
    const markerText = isStart ? 'S' : isDestination ? 'D' : '';

    ctx.beginPath();
    if (node.type === 'corridor') {
      ctx.roundRect(point.x - size, point.y - size, size * 2, size * 2, 3);
    } else if (node.type === 'stairs') {
      ctx.moveTo(point.x, point.y - size);
      ctx.lineTo(point.x + size, point.y + size);
      ctx.lineTo(point.x - size, point.y + size);
      ctx.closePath();
    } else {
      ctx.roundRect(point.x - size, point.y - size, size * 2, size * 2, node.type === 'lift' ? 4 : 7);
    }
    ctx.fillStyle = node.type === 'stairs' ? '#fae9e5' : markerColor;
    ctx.fill();
    ctx.lineWidth = isRouteNode ? 3 : 2;
    ctx.strokeStyle = isStart ? '#386c9a' : isDestination ? '#b84c3f' : node.type === 'stairs' ? '#b84c3f' : '#fff';
    ctx.stroke();

    if (markerText) {
      ctx.font = '700 9px Manrope, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#fff';
      ctx.fillText(markerText, point.x, point.y + .5);
    }

    ctx.font = `${isRouteNode ? '700' : '600'} 10px Manrope, sans-serif`;
    const labelWidth = ctx.measureText(label).width + 16;
    const labelX = Math.min(width - labelWidth - 9, Math.max(9, point.x - labelWidth / 2));
    const labelY = Math.max(9, point.y - 34);
    ctx.beginPath();
    ctx.roundRect(labelX, labelY, labelWidth, 22, 6);
    ctx.fillStyle = '#fff';
    ctx.fill();
    ctx.strokeStyle = isStart ? '#386c9a' : isDestination ? '#b84c3f' : '#d8e1d8';
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = isStart ? '#2d5b82' : isDestination ? '#923e34' : '#29342e';
    ctx.fillText(label, labelX + labelWidth / 2, labelY + 11);
  }
}

function parseConfirmedRoute(text) {
  const matches = [...text.matchAll(ROUTE_LINE)];
  if (matches.length !== 1) return { text: text.trim(), route: [] };
  const match = matches[0];
  const ids = match[1].split(/\s*->\s*/).map(id => id.trim()).filter(Boolean);
  const cleanText = `${text.slice(0, match.index)}${text.slice(match.index + match[0].length)}`.trim();
  return { text: cleanText, route: validateRoute(ids, elements.profile.value) };
}

function validateRoute(ids, profile = 'standard') {
  if (ids.length < 2 || new Set(ids).size !== ids.length) return [];
  const nodeById = new Map(graph.nodes.map(node => [node.id, node]));
  const stepFreeOnly = ['wheelchair', 'step_free'].includes(profile);
  const validNodes = ids.every(id => {
    const node = nodeById.get(id);
    return node && node.operational !== false && (!stepFreeOnly || node.step_free !== false);
  });
  const edgeByKey = new Map(graph.edges.map(edge => [[edge.from, edge.to].sort().join('|'), edge]));
  const validEdges = ids.slice(1).every((id, index) => {
    const edge = edgeByKey.get([ids[index], id].sort().join('|'));
    return edge && (!stepFreeOnly || edge.wheelchair_accessible !== false);
  });
  return validNodes && validEdges ? ids : [];
}

function updateRoute(route) {
  confirmedRoute = route;
  const active = route.length > 1;
  elements.shareRoute.disabled = !active || !lastAssistantText;
  const shareHelp = !active
    ? 'Request directions to enable sharing after the routing agent returns a confirmed route.'
    : !lastAssistantText
      ? 'The confirmed route has no directions to share.'
      : 'A confirmed route is available. Phone sharing uses the configured share origin.';
  document.querySelector('#share-route-help').textContent = shareHelp;
  elements.shareRoute.title = !active
    ? 'Available after the routing agent returns a confirmed route'
    : !lastAssistantText
      ? 'Sharing is unavailable because the routing response included no directions'
      : 'Share the confirmed route';
  elements.status.textContent = active ? `${route.length - 1} route segments` : 'No confirmed route';
  elements.status.classList.toggle('active', active);
  elements.empty.hidden = active;
  elements.count.textContent = active ? `${route.length} stops · ${locationName(route[0])} to ${locationName(route.at(-1))}` : `${graph.nodes.length} places`;
  if (active) {
    const destination = graph.nodes.find(node => node.id === route.at(-1));
    if (destination) currentFloor = destination.floor;
    setFloor(currentFloor);
  } else drawMap();
}

function responseText(payload) {
  const response = payload?.response;
  if (typeof response === 'string') return response;
  if (typeof response?.text === 'string') return response.text;
  if (typeof payload?.text === 'string') return payload.text;
  throw new Error('Navigation service returned an unexpected response.');
}

function setAgentState(agent, state, announce = true) {
  const card = document.querySelector(`[data-agent="${agent}"]`);
  const label = AGENT_LABELS[agent];
  if (!card || !label || card.dataset.state === state) return;

  card.dataset.state = state;
  card.querySelector('.agent-state').textContent = {
    active: 'Working',
    completed: 'Complete',
    failed: 'Failed',
    cancelled: 'Stopped',
    idle: 'Not called',
  }[state] || 'Not called';
  elements.networkFlow.classList.toggle(
    'has-active-agent',
    Boolean(elements.networkFlow.querySelector('.network-specialists [data-state="active"]')),
  );

  if (announce) {
    const stateText = {
      active: 'started',
      completed: 'completed',
      failed: 'failed',
      cancelled: 'stopped before completion',
    }[state];
    elements.networkStatus.textContent = `${label} ${stateText}.`;
    const item = document.createElement('li');
    item.dataset.state = state;
    item.textContent = `${label} · ${stateText}`;
    elements.networkActivity.append(item);
    while (elements.networkActivity.children.length > 12) {
      elements.networkActivity.firstElementChild.remove();
    }
  }
}

function resetNetworkActivity() {
  specialistActivitySeen = false;
  for (const card of document.querySelectorAll('[data-agent]')) {
    card.dataset.state = 'idle';
    card.querySelector('.agent-state').textContent = 'Not called';
  }
  elements.networkFlow.classList.remove('has-active-agent');
  elements.networkActivity.replaceChildren();
  elements.networkStatus.textContent = 'No request in progress. Activity will appear here after a request starts.';
}

function completeNetworkActivity() {
  for (const card of document.querySelectorAll('[data-agent][data-state="active"]')) {
    setAgentState(card.dataset.agent, 'completed');
  }
  setAgentState('accessible_navigation_assistant', 'completed');
  if (!specialistActivitySeen) {
    elements.networkStatus.textContent = 'Neuro-SAN completed; no specialist activity events were emitted.';
  } else {
    elements.networkStatus.textContent = 'Neuro-SAN completed. The activity shown came from its execution stream.';
  }
}

function stopNetworkActivity() {
  for (const card of document.querySelectorAll('[data-agent][data-state="active"]')) {
    setAgentState(card.dataset.agent, 'cancelled');
  }
  elements.networkStatus.textContent = 'Request stopped. The backend may take a moment to notice the closed stream.';
}

function failNetworkActivity() {
  for (const card of document.querySelectorAll('[data-agent][data-state="active"]')) {
    setAgentState(card.dataset.agent, 'failed');
  }
  elements.networkStatus.textContent = 'The Neuro-SAN request did not complete.';
}

async function readNavigationStream(response, currentRequestId) {
  if (!response.headers.get('content-type')?.includes('json-lines')) {
    return response.json();
  }

  if (!response.body) throw new Error('Navigation service returned an empty response stream.');
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let finalResponse;

  const consumeLine = line => {
    if (!line.trim()) return;
    const record = JSON.parse(line);
    if (typeof record.error === 'string') throw new Error(record.error);
    if (record.activity && currentRequestId === requestId) {
      if (record.activity.agent !== 'accessible_navigation_assistant') specialistActivitySeen = true;
      setAgentState(record.activity.agent, record.activity.state);
      return;
    }
    const message = record.response;
    if (!message || typeof message !== 'object') return;
    if (message.type === 'AGENT_FRAMEWORK'
      && typeof message.text === 'string'
      && message.chat_context
      && typeof message.chat_context === 'object') {
      finalResponse = message;
    }
  };

  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let lineEnd = buffer.indexOf('\n');
      while (lineEnd !== -1) {
        consumeLine(buffer.slice(0, lineEnd));
        buffer = buffer.slice(lineEnd + 1);
        lineEnd = buffer.indexOf('\n');
      }
    }
    buffer += decoder.decode();
    if (buffer.trim()) consumeLine(buffer);
  } finally {
    reader.releaseLock();
  }

  if (!finalResponse) throw new Error('Navigation service finished without a final response.');
  return { response: finalResponse };
}

function stopSpeaking() {
  if (speechUtterance) {
    speechUtterance.onend = null;
    speechUtterance.onerror = null;
    speechUtterance = null;
  }
  if ('speechSynthesis' in window) window.speechSynthesis.cancel();
  elements.readAloud.textContent = 'Read aloud';
  elements.readAloud.setAttribute('aria-label', 'Read latest directions aloud');
  elements.sharedReadAloud.textContent = 'Start spoken guidance';
  elements.sharedReadAloud.setAttribute('aria-label', 'Start spoken guidance');
}

function readDirectionsAloud() {
  const button = sharedRouteMode ? elements.sharedReadAloud : elements.readAloud;
  const status = sharedRouteMode ? elements.sharedGuideStatus : elements.voiceStatus;
  if ('speechSynthesis' in window && window.speechSynthesis.speaking) {
    stopSpeaking();
    status.textContent = 'Spoken directions stopped.';
    return;
  }
  if (!lastAssistantText) {
    status.textContent = 'There are no directions to read yet.';
    return;
  }
  if (!('speechSynthesis' in window)) {
    status.textContent = 'Spoken directions are not supported in this browser. Use your screen reader.';
    return;
  }

  speechUtterance = new SpeechSynthesisUtterance(lastAssistantText);
  speechUtterance.lang = document.documentElement.lang || 'en-US';
  speechUtterance.onend = () => {
    speechUtterance = null;
    stopSpeaking();
    status.textContent = 'Finished reading directions.';
  };
  speechUtterance.onerror = () => {
    speechUtterance = null;
    stopSpeaking();
    status.textContent = 'Could not read directions aloud. Try again or use your screen reader.';
  };
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(speechUtterance);
  button.textContent = sharedRouteMode ? 'Stop spoken guidance' : 'Stop reading';
  button.setAttribute('aria-label', sharedRouteMode ? 'Stop spoken guidance' : 'Stop reading directions');
  status.textContent = 'Reading directions aloud.';
}

function startVoiceInput() {
  if (busy) {
    elements.voiceStatus.textContent = 'Wait for the current request to finish before dictating.';
    return;
  }
  if (!SpeechRecognitionApi) {
    elements.voiceStatus.textContent = 'Voice input is not supported in this browser. Type your request instead.';
    return;
  }
  if (speechRecognition) {
    speechRecognition.stop();
    return;
  }

  speechRecognition = new SpeechRecognitionApi();
  speechRecognition.lang = document.documentElement.lang || 'en-US';
  speechRecognition.continuous = false;
  speechRecognition.interimResults = false;
  speechRecognition.onstart = () => {
    elements.voiceInput.textContent = 'Stop listening';
    elements.voiceInput.setAttribute('aria-label', 'Stop voice input');
    elements.voiceInput.setAttribute('aria-pressed', 'true');
    elements.voiceStatus.textContent = 'Listening. Speak your request.';
  };
  speechRecognition.onresult = event => {
    const transcript = event.results?.[0]?.[0]?.transcript?.trim();
    if (transcript) {
      elements.prompt.value = transcript;
      elements.prompt.focus();
      elements.voiceStatus.textContent = 'Voice input captured. Review your request, then send it.';
    }
  };
  speechRecognition.onerror = event => {
    const message = event.error === 'not-allowed'
      ? 'Microphone access was denied. Allow microphone access or type your request.'
      : event.error === 'no-speech'
        ? 'No speech detected. Try again or type your request.'
        : `Voice input failed (${event.error}). Type your request instead.`;
    elements.voiceStatus.textContent = message;
  };
  speechRecognition.onend = () => {
    speechRecognition = null;
    elements.voiceInput.textContent = 'Voice input';
    elements.voiceInput.setAttribute('aria-label', 'Start voice input');
    elements.voiceInput.setAttribute('aria-pressed', 'false');
  };
  try {
    speechRecognition.start();
  } catch (error) {
    speechRecognition = null;
    elements.voiceStatus.textContent = `Could not start voice input: ${error.message}`;
  }
}

async function sendPrompt(text) {
  if (busy || !text.trim()) return;
  if (speechRecognition) speechRecognition.stop();
  stopSpeaking();
  lastAssistantText = '';
  elements.readAloud.disabled = true;
  const currentRequestId = ++requestId;
  const controller = new AbortController();
  activeRequestController = controller;
  busy = true;
  elements.send.disabled = true;
  elements.stopChat.hidden = false;
  elements.connection.className = 'connection-state';
  elements.connection.textContent = 'Waiting for navigation service…';
  resetNetworkActivity();
  addMessage('user', text.trim());
  updateRoute([]);
  const currentLocation = elements.locations.value;
  const profile = elements.profile.value;
  const selectedContext = [
    `Current location selected in the interface: ${locationName(currentLocation)} (${currentLocation}).`,
    `Accessibility profile selected in the interface: ${profile}.`,
    'Use these selected values unless the user explicitly corrects them; do not ask for them again.',
  ].join(' ');
  try {
    const response = await fetch(API_PATH, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json-lines' },
      body: JSON.stringify({
        user_message: { text: `${text.trim()}\n\n${selectedContext}` },
        sly_data: { current_location: currentLocation, profile },
        chat_context: chatContext,
        chat_filter: { chat_filter_type: 'MAXIMAL' },
      }),
      signal: AbortSignal.any([controller.signal, AbortSignal.timeout(130000)]),
    });
    if (!response.ok) throw new Error(`Navigation service returned HTTP ${response.status}.`);
    setAgentState('accessible_navigation_assistant', 'active');
    const payload = await readNavigationStream(response, currentRequestId);
    if (currentRequestId !== requestId) return;
    const rawText = responseText(payload);
    if (payload.response && typeof payload.response === 'object' && payload.response.chat_context !== undefined) {
      chatContext = payload.response.chat_context;
    }
    const parsed = parseConfirmedRoute(rawText);
    lastAssistantText = parsed.text;
    elements.readAloud.disabled = !lastAssistantText;
    addMessage('assistant', lastAssistantText);
    updateRoute(parsed.route);
    elements.connection.className = 'connection-state online';
    elements.connection.textContent = 'Navigation service connected';
    completeNetworkActivity();
  } catch (error) {
    if (currentRequestId !== requestId) return;
    if (error.name === 'AbortError') {
      addMessage('notice', 'Request stopped.');
      elements.connection.className = 'connection-state';
      elements.connection.textContent = 'Request stopped';
      stopNetworkActivity();
    } else {
      addMessage('error', `${error.name === 'TimeoutError' ? 'Request timed out.' : error.message} Check that backend is running and reachable through local proxy.`);
      elements.connection.className = 'connection-state offline';
      elements.connection.textContent = 'Navigation service unavailable';
      failNetworkActivity();
    }
  } finally {
    if (currentRequestId === requestId) {
      activeRequestController = undefined;
      busy = false;
      elements.send.disabled = false;
      elements.stopChat.hidden = true;
      elements.stopChat.disabled = false;
      elements.prompt.focus();
    }
  }
}

async function openRouteShare() {
  if (confirmedRoute.length < 2) return;
  elements.routeQr.removeAttribute('src');
  elements.accessibleRouteLink.removeAttribute('href');
  elements.shareStatus.textContent = 'Preparing the route link…';
  elements.shareDialog.showModal();
  try {
    const response = await fetch('/api/share-origin');
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || 'Phone sharing is unavailable.');
    elements.shareHelp.textContent = payload.insecureDemo
      ? 'Demo only: this link uses unencrypted HTTP with no sign-in. Scan it only on trusted private Wi-Fi and do not share sensitive information. For a visually impaired traveler, open the accessible link directly or save it to an NFC tag; spoken and screen-reader directions are available.'
      : 'For a visually impaired traveler, share this accessible link directly or save it to an NFC tag. On the phone, choose Start spoken guidance; written directions are also available to screen readers.';
    const sharedUrl = new URL('/', payload.origin);
    sharedUrl.searchParams.set('route', confirmedRoute.join(','));
    sharedUrl.hash = new URLSearchParams({
      directions: lastAssistantText,
      profile: elements.profile.value,
    }).toString();
    elements.accessibleRouteLink.href = sharedUrl.href;
    elements.routeQr.alt = `QR code linking to the route from ${locationName(confirmedRoute[0])} to ${locationName(confirmedRoute.at(-1))}`;
    elements.routeQr.src = `/api/qr?text=${encodeURIComponent(sharedUrl.href)}`;
    elements.shareStatus.textContent = `Route link ready for ${payload.origin}.`;
  } catch (error) {
    elements.shareStatus.textContent = error.message;
  }
}

async function copyAccessibleRouteLink() {
  if (!elements.accessibleRouteLink.hasAttribute('href')) {
    elements.shareStatus.textContent = 'Create the route link before copying it.';
    return;
  }
  const link = elements.accessibleRouteLink.href;
  try {
    await navigator.clipboard.writeText(link);
    elements.shareStatus.textContent = 'Accessible route link copied.';
  } catch {
    const temporaryInput = document.createElement('textarea');
    temporaryInput.value = link;
    temporaryInput.setAttribute('readonly', '');
    temporaryInput.style.position = 'fixed';
    temporaryInput.style.opacity = '0';
    document.body.append(temporaryInput);
    temporaryInput.select();
    const copied = document.execCommand('copy');
    temporaryInput.remove();
    elements.shareStatus.textContent = copied
      ? 'Accessible route link copied.'
      : `Copy this accessible route link: ${link}`;
  }
}

function showSharedRoute() {
  const params = new URLSearchParams(window.location.search);
  const routeValue = params.get('route');
  if (!routeValue) return;
  const fragment = new URLSearchParams(window.location.hash.slice(1));
  const profileValue = fragment.get('profile');
  const profile = ['wheelchair', 'step_free', 'visually_impaired', 'standard'].includes(profileValue)
    ? profileValue
    : 'standard';
  const route = validateRoute(routeValue.split(',').map(id => id.trim()).filter(Boolean), profile);
  if (!route.length) {
    elements.connection.className = 'connection-state offline';
    elements.connection.textContent = `The shared route is invalid or unavailable for the ${profile} profile in this sample map.`;
    return;
  }
  sharedRouteMode = true;
  document.body.classList.add('shared-route');
  const origin = locationName(route[0]);
  const destination = locationName(route.at(-1));
  const directions = fragment.get('directions')?.trim() || '';
  elements.profile.value = profile;
  lastAssistantText = directions;
  elements.sharedGuidance.hidden = false;
  elements.sharedGuidanceTitle.textContent = `Directions to ${destination}`;
  elements.sharedDirections.textContent = directions || 'No directions were included in the routing response. Return to the assistant to request directions.';
  elements.sharedReadAloud.disabled = !directions || !('speechSynthesis' in window);
  elements.sharedReadAloud.setAttribute('aria-describedby', 'shared-guide-status');
  elements.sharedGuideStatus.textContent = directions
    ? ''
    : 'Spoken guidance is unavailable because the routing response did not provide directions.';
  if (!('speechSynthesis' in window)) {
    elements.sharedGuideStatus.textContent = 'Speech output is unavailable. Use your device screen reader to read the directions.';
  }
  document.querySelector('#map-title').textContent = `Route to ${destination}`;
  document.title = `Route to ${destination} | Wayfinder`;
  updateRoute(route);
  elements.connection.textContent = 'Shared route loaded · sample map only';
}

async function initialise() {
  try {
    const response = await fetch(graphUrl, { cache: 'no-store' });
    if (!response.ok) throw new Error('Graph data could not be loaded.');
    graph = await response.json();
    if (!Array.isArray(graph.nodes) || !Array.isArray(graph.edges) || !graph.nodes.length) throw new Error('Graph data is invalid.');
    populateLocations();
    currentFloor = floors()[0];
    setFloor(currentFloor);
    elements.count.textContent = `${graph.nodes.length} places`;
    elements.connection.className = 'connection-state';
    elements.connection.textContent = 'Map loaded · backend checked when you send a request';
    new ResizeObserver(drawMap).observe(elements.canvas);
    showSharedRoute();
  } catch (error) {
    elements.connection.className = 'connection-state offline';
    elements.connection.textContent = error.message;
  }
}

elements.form.addEventListener('submit', event => {
  event.preventDefault();
  const text = elements.prompt.value;
  elements.prompt.value = '';
  sendPrompt(text);
});
elements.voiceInput.addEventListener('click', startVoiceInput);
elements.readAloud.addEventListener('click', readDirectionsAloud);
elements.sharedReadAloud.addEventListener('click', readDirectionsAloud);
elements.stopChat.addEventListener('click', () => {
  if (!activeRequestController) return;
  elements.stopChat.disabled = true;
  elements.connection.textContent = 'Stopping request…';
  activeRequestController.abort();
});
elements.shareRoute.addEventListener('click', openRouteShare);
elements.copyRouteLink.addEventListener('click', copyAccessibleRouteLink);
elements.shareRouteLink.hidden = typeof navigator.share !== 'function';
elements.shareRouteLink.addEventListener('click', async () => {
  try {
    await navigator.share({ title: 'Wayfinder route', url: elements.accessibleRouteLink.href });
  } catch (error) {
    if (error.name !== 'AbortError') elements.shareStatus.textContent = `Could not share the route: ${error.message}`;
  }
});
elements.routeQr.addEventListener('error', () => {
  elements.shareStatus.textContent = 'Could not generate the QR code. Copy or share the accessible link instead.';
});
document.querySelector('#close-share').addEventListener('click', () => elements.shareDialog.close());
document.querySelectorAll('.scenarios button').forEach(button => {
  button.addEventListener('click', () => {
    if (button.dataset.profile) elements.profile.value = button.dataset.profile;
    if (button.dataset.location) elements.locations.value = button.dataset.location;
    elements.prompt.value = button.dataset.prompt;
    elements.prompt.focus();
  });
});
document.querySelector('#clear-chat').addEventListener('click', () => {
  requestId += 1;
  activeRequestController?.abort();
  activeRequestController = undefined;
  busy = false;
  elements.stopChat.hidden = true;
  elements.stopChat.disabled = false;
  elements.send.disabled = false;
  stopSpeaking();
  if (speechRecognition) speechRecognition.stop();
  chatContext = {};
  lastAssistantText = '';
  elements.readAloud.disabled = true;
  elements.voiceStatus.textContent = 'Conversation cleared.';
  elements.sharedGuideStatus.textContent = '';
  elements.conversation.replaceChildren();
  updateRoute([]);
  elements.connection.textContent = 'Conversation cleared';
  resetNetworkActivity();
});
window.addEventListener('resize', drawMap);
initialise();