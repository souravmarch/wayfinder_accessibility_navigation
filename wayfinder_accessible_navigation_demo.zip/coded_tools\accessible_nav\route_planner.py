"""neuro-san CodedTool: plan an accessible route.

HOCON args the LLM should supply:  source, destination, profile
Fallbacks: if the LLM omits a value, we read it from sly_data
(sly_data["current_location"], sly_data["profile"]) which the frontend sends.
"""
from typing import Any
from typing import Dict

from neuro_san.interfaces.coded_tool import CodedTool
from routing.router import plan_route


class RoutePlanner(CodedTool):
    """Wraps routing.router.plan_route."""

    async def async_invoke(self, args: Dict[str, Any], sly_data: Dict[str, Any]) -> Any:
        source = args.get("source") or sly_data.get("current_location")
        destination = args.get("destination")
        profile = args.get("profile") or sly_data.get("profile") or "standard"

        if not source or not destination:
            return {"found": False, "route": [], "distance": 0, "steps": [],
                    "reason": "Both a source and a destination are required."}

        result = plan_route(source, destination, profile)

        # Bulletin board for the frontend (so the map can highlight the path).
        sly_data["route"] = result.get("route", [])
        sly_data["route_found"] = result.get("found", False)
        return result
