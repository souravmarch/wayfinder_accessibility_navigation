"""Load data/graph.json into a NetworkX graph.

Node attributes (all optional except id/name/type/floor):
    step_free (bool, default True)   - False for stairs, steps, etc.
    operational (bool, default True) - set False when a lift is out of service
    aliases (list[str])              - alternative names used by resolve_location
    landmark (str)                   - used in directions for visually impaired users
    x, y (number)                    - coordinates on the floor-plan SVG (for the map)

Edge attributes:
    distance (number, metres)
    wheelchair_accessible (bool, default True)
"""
import json
from pathlib import Path

import networkx as nx

DEFAULT_GRAPH_PATH = Path(__file__).resolve().parent.parent / "data" / "graph.json"


def load_graph(path=None) -> nx.Graph:
    """Read the JSON file and return an undirected NetworkX graph."""
    path = Path(path) if path else DEFAULT_GRAPH_PATH
    with open(path, encoding="utf-8") as handle:
        data = json.load(handle)

    graph = nx.Graph()
    for node in data["nodes"]:
        attrs = dict(node)
        node_id = attrs.pop("id")
        attrs.setdefault("step_free", True)
        attrs.setdefault("operational", True)
        attrs.setdefault("aliases", [])
        graph.add_node(node_id, **attrs)

    for edge in data["edges"]:
        attrs = dict(edge)
        source = attrs.pop("from")
        target = attrs.pop("to")
        attrs.setdefault("wheelchair_accessible", True)
        graph.add_edge(source, target, **attrs)

    return graph
