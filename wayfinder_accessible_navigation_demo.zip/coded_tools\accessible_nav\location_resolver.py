"""neuro-san CodedTool: turn free text ("Neptune room") into node ids.

HOCON args the LLM should supply:  text
Returns {"matches": [{"id": ..., "name": ..., "score": ...}]} best first.
The Location Agent should pick the top match, or ask the user if scores are close.
"""
from typing import Any
from typing import Dict

from neuro_san.interfaces.coded_tool import CodedTool
from routing.router import resolve_location


class LocationResolver(CodedTool):
    """Wraps routing.router.resolve_location."""

    async def async_invoke(self, args: Dict[str, Any], sly_data: Dict[str, Any]) -> Any:
        text = args.get("text", "")
        return resolve_location(text)
