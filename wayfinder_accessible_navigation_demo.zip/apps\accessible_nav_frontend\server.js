const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const QRCode = require('qrcode');

const root = __dirname;
const graphPath = path.resolve(root, '..', '..', 'data', 'graph.json');
const host = process.env.HOST || '127.0.0.1';
const port = Number(process.env.PORT || 4174);
const apiTarget = new URL(process.env.NAV_API_TARGET || 'http://127.0.0.1:8080');
const allowInsecureDemoLan = process.env.WAYFINDER_DEMO_LAN === 'true';
const allowedApiPath = '/api/v1/accessible_nav/streaming_chat';
const maxBodyBytes = 1024 * 1024;
const maxStreamLineBytes = 4 * 1024 * 1024;
const maxQrTextLength = 3000;
const navigationAgents = new Set([
  'accessibility_agent',
  'location_agent',
  'route_agent',
  'facility_agent',
  'voice_agent',
]);
const mimeTypes = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
};

function isLoopbackHost(value) {
  return ['127.0.0.1', 'localhost', '::1'].includes(value);
}

function isPrivateIpv4(value) {
  if (!/^(\d{1,3}\.){3}\d{1,3}$/.test(value)) return false;
  const octets = value.split('.').map(Number);
  if (octets.some(octet => octet < 0 || octet > 255)) return false;
  return octets[0] === 10
    || (octets[0] === 172 && octets[1] >= 16 && octets[1] <= 31)
    || (octets[0] === 192 && octets[1] === 168);
}

if (!['http:', 'https:'].includes(apiTarget.protocol)) throw new Error('NAV_API_TARGET must use HTTP or HTTPS.');
if (!isLoopbackHost(host) && !(allowInsecureDemoLan && isPrivateIpv4(host))) {
  throw new Error('Bind to loopback, or opt in to a private IPv4 demo LAN with WAYFINDER_DEMO_LAN=true.');
}

function send(response, status, body, contentType = 'application/json; charset=utf-8') {
  response.writeHead(status, {
    'Content-Type': contentType,
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
  });
  response.end(body);
}

function getShareOrigin() {
  if (!process.env.WAYFINDER_SHARE_ORIGIN) {
    throw new Error('Set WAYFINDER_SHARE_ORIGIN to the browser-reachable base URL for QR links.');
  }
  const configured = new URL(process.env.WAYFINDER_SHARE_ORIGIN);
  const hasNoExtraUrlParts = configured.pathname === '/' && !configured.search && !configured.hash
    && !configured.username && !configured.password;
  const secureOrigin = configured.protocol === 'https:';
  const demoLanOrigin = allowInsecureDemoLan
    && isPrivateIpv4(host)
    && configured.protocol === 'http:'
    && configured.hostname === host
    && configured.port === String(port);
  if (!hasNoExtraUrlParts || (!secureOrigin && !demoLanOrigin)) {
    throw new Error(
      'WAYFINDER_SHARE_ORIGIN must be an HTTPS origin, or the exact bound private-LAN HTTP origin '
      + 'when WAYFINDER_DEMO_LAN=true.',
    );
  }
  return configured.origin;
}

async function sendQrCode(request, response, url) {
  if (request.method !== 'GET') return send(response, 405, JSON.stringify({ error: 'Method not allowed.' }));
  const text = url.searchParams.get('text');
  if (!text || text.length > maxQrTextLength) {
    return send(response, 400, JSON.stringify({ error: `QR text must be between 1 and ${maxQrTextLength} characters.` }));
  }
  try {
    const shareUrl = new URL(text);
    if (shareUrl.origin !== getShareOrigin() || shareUrl.pathname !== '/') {
      return send(response, 400, JSON.stringify({ error: 'QR links must point to this Wayfinder server.' }));
    }
    const svg = await QRCode.toString(text, { type: 'svg', errorCorrectionLevel: 'M', margin: 2, width: 320 });
    return send(response, 200, svg, 'image/svg+xml; charset=utf-8');
  } catch (error) {
    return send(response, 400, JSON.stringify({ error: error.message }));
  }
}

function streamActivity(record, finalResponses) {
  const message = record?.response;
  if (!message || typeof message !== 'object') return null;

  if (message.type === 'AGENT' && message.structure?.invoking_start === true) {
    const agent = message.structure.invoked_agent_name;
    if (navigationAgents.has(agent)) return { activity: { agent, state: 'active' } };
  }

  if (message.type === 'AGENT_PROGRESS') {
    const agent = message.structure?.agent_name || message.structure?.agent;
    if (navigationAgents.has(agent)) return { activity: { agent, state: 'active' } };
  }

  if (message.type === 'AGENT_TOOL_RESULT' && Array.isArray(message.tool_result_origin)) {
    const origin = message.tool_result_origin;
    const agent = origin.length === 2 ? origin[1]?.tool : undefined;
    if (navigationAgents.has(agent)) return { activity: { agent, state: 'completed' } };
  }

  if (message.type === 'AGENT_FRAMEWORK'
    && typeof message.text === 'string'
    && message.chat_context
    && typeof message.chat_context === 'object') {
    const finalResponse = { type: message.type, text: message.text };
    finalResponse.chat_context = message.chat_context;
    finalResponses.preferred = { response: finalResponse };
  }
  return null;
}

async function writeStreamFrame(response, frame) {
  if (response.destroyed) throw new Error('Client disconnected.');
  if (!response.write(`${JSON.stringify(frame)}\n`)) {
    await new Promise((resolve, reject) => {
      const cleanup = () => {
        response.off('drain', onDrain);
        response.off('close', onClose);
        response.off('error', onError);
      };
      const onDrain = () => {
        cleanup();
        resolve();
      };
      const onClose = () => {
        cleanup();
        reject(new Error('Client disconnected.'));
      };
      const onError = error => {
        cleanup();
        reject(error);
      };
      response.once('drain', onDrain);
      response.once('close', onClose);
      response.once('error', onError);
    });
  }
}

async function proxyChatStream(upstream, response, signal) {
  if (!upstream.body) throw new Error('Navigation backend returned an empty stream.');
  const reader = upstream.body.getReader();
  const decoder = new TextDecoder();
  const finalResponses = {};
  let buffer = '';

  const consumeLine = async line => {
    if (!line.trim()) return false;
    const record = JSON.parse(line);
    if (typeof record.error === 'string') {
      await writeStreamFrame(response, { error: 'Navigation request failed.' });
      return true;
    }
    const activity = streamActivity(record, finalResponses);
    if (activity) await writeStreamFrame(response, activity);
    return false;
  };

  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      if (Buffer.byteLength(buffer, 'utf8') > maxStreamLineBytes && !buffer.includes('\n')) {
        throw new Error('Navigation backend returned an oversized stream record.');
      }
      let lineEnd = buffer.indexOf('\n');
      while (lineEnd !== -1) {
        const line = buffer.slice(0, lineEnd);
        buffer = buffer.slice(lineEnd + 1);
        if (Buffer.byteLength(line, 'utf8') > maxStreamLineBytes) {
          throw new Error('Navigation backend returned an oversized stream record.');
        }
        if (await consumeLine(line)) {
          await reader.cancel();
          response.end();
          return;
        }
        lineEnd = buffer.indexOf('\n');
      }
    }
    buffer += decoder.decode();
    if (buffer.trim() && await consumeLine(buffer)) {
      response.end();
      return;
    }
    const finalResponse = finalResponses.preferred;
    if (finalResponse) await writeStreamFrame(response, finalResponse);
    response.end();
  } finally {
    if (signal.aborted) await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
}

async function proxyChat(request, response) {
  if (request.method !== 'POST') return send(response, 405, JSON.stringify({ error: 'Method not allowed.' }));
  const contentType = request.headers['content-type'] || '';
  if (!contentType.toLowerCase().startsWith('application/json')) return send(response, 415, JSON.stringify({ error: 'Expected application/json.' }));

  const chunks = [];
  let bytes = 0;
  for await (const chunk of request) {
    bytes += chunk.length;
    if (bytes > maxBodyBytes) return send(response, 413, JSON.stringify({ error: 'Request body too large.' }));
    chunks.push(chunk);
  }
  const body = Buffer.concat(chunks);
  try {
    const parsed = JSON.parse(body.toString('utf8'));
    if (!parsed || typeof parsed !== 'object' || typeof parsed.user_message?.text !== 'string' || !parsed.sly_data || typeof parsed.sly_data !== 'object') {
      return send(response, 400, JSON.stringify({ error: 'Invalid navigation request.' }));
    }
  } catch {
    return send(response, 400, JSON.stringify({ error: 'Malformed JSON.' }));
  }

  const target = new URL(allowedApiPath, apiTarget);
  const controller = new AbortController();
  const abortUpstream = () => {
    if (!response.writableEnded) controller.abort();
  };
  response.on('close', abortUpstream);
  try {
    const upstream = await fetch(target, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json-lines' },
      body,
      signal: AbortSignal.any([controller.signal, AbortSignal.timeout(125000)]),
    });
    if (!upstream.ok) {
      const payload = await upstream.arrayBuffer();
      response.writeHead(upstream.status, {
        'Content-Type': upstream.headers.get('content-type') || 'application/json; charset=utf-8',
        'Cache-Control': 'no-store',
        'X-Content-Type-Options': 'nosniff',
        'Referrer-Policy': 'no-referrer',
      });
      response.end(Buffer.from(payload));
      return;
    }
    response.writeHead(upstream.status, {
      'Content-Type': 'application/json-lines; charset=utf-8',
      'Cache-Control': 'no-cache, no-store, no-transform',
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'no-referrer',
      'X-Accel-Buffering': 'no',
      'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
    });
    await proxyChatStream(upstream, response, controller.signal);
  } catch (error) {
    if (controller.signal.aborted) return;
    if (response.headersSent) {
      response.destroy(error);
      return;
    }
    const timedOut = error.name === 'TimeoutError';
    send(response, timedOut ? 504 : 502, JSON.stringify({ error: timedOut ? 'Backend request timed out.' : 'Navigation backend unavailable.' }));
  } finally {
    response.off('close', abortUpstream);
  }
}

const requestHandler = (request, response) => {
  const url = new URL(request.url, `http://${request.headers.host || `${host}:${port}`}`);
  if (url.pathname.startsWith('/api/')) {
    if (url.pathname === '/api/share-origin') {
      if (request.method !== 'GET') return send(response, 405, JSON.stringify({ error: 'Method not allowed.' }));
      try {
        const origin = getShareOrigin();
        return send(response, 200, JSON.stringify({ origin, insecureDemo: new URL(origin).protocol === 'http:' }));
      } catch (error) {
        return send(response, 503, JSON.stringify({ error: error.message }));
      }
    }
    if (url.pathname === '/api/qr') {
      sendQrCode(request, response, url);
      return;
    }
    if (url.pathname !== allowedApiPath) return send(response, 404, JSON.stringify({ error: 'Unknown API route.' }));
    proxyChat(request, response);
    return;
  }
  if (request.method !== 'GET' && request.method !== 'HEAD') return send(response, 405, 'Method not allowed.', 'text/plain; charset=utf-8');

  let pathname;
  try {
    pathname = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
  } catch {
    return send(response, 400, 'Malformed URL path.', 'text/plain; charset=utf-8');
  }
  const filePath = pathname === '/data/graph.json'
    ? graphPath
    : path.resolve(root, `.${pathname}`);
  if (pathname !== '/data/graph.json' && !filePath.startsWith(`${root}${path.sep}`)) {
    return send(response, 404, 'Not found.', 'text/plain; charset=utf-8');
  }
  fs.readFile(filePath, (error, data) => {
    if (error) return send(response, 404, 'Not found.', 'text/plain; charset=utf-8');
    const type = mimeTypes[path.extname(filePath)] || 'application/octet-stream';
    response.writeHead(200, {
      'Content-Type': type,
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'no-referrer',
      'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
    });
    response.end(request.method === 'HEAD' ? undefined : data);
  });
};

const server = http.createServer(requestHandler);

server.listen(port, host, () => {
  console.log(`Wayfinder demo ready at http://${host}:${port}`);
  try {
    console.log(`Phone share URL: ${getShareOrigin()}`);
  } catch (error) {
    console.log(`Phone sharing unavailable: ${error.message}`);
  }
  console.log(`Navigation backend: ${apiTarget.origin}`);
  if (allowInsecureDemoLan) {
    console.warn('Insecure LAN demo enabled: use only on a trusted private Wi-Fi with fictional, non-sensitive data.');
  }
});