# Copyright © 2026 Cognizant Technology Solutions Corp, www.cognizant.com.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# END COPYRIGHT
"""
The common instructions: the fixed texts the agent network designer adds to every agent's custom instructions on
save.
"""


class DesignerCommonInstructions:  # pylint: disable=too-few-public-methods
    """
    The wording of the common instructions the designer adds to each agent's custom instructions on save.

    An agent's "instructions" in agent_network_definition hold only its custom instructions, the agent's own
    text. Every save adds the common instructions back, and which pieces an agent gets depends on its role:

    - the prefix, for every LLM agent;
    - the front man's three fixed lines, for the top agent;
    - the demo sentence, for leaf agents when demo mode is on;
    - the AAOSA instructions, for the top agent and agents with tools. Their text lives in
      registries/aaosa.hocon, the file every generated network includes, so it is not repeated here.

    HoconAgentNetworkAssembler builds its header and top-agent template from these constants, and
    CommonInstructionStripper matches copies by the same constants, so a change here changes what is written and
    what is stripped at once. deployable_template.hocon and deployable_template_demo.hocon are HOCON and cannot
    import them; a test pins their copies to these values.

    Changing a wording is a deliberate step, and a test pins each wording so that it is made knowingly. The
    stripper keeps no old wordings: a network saved under the old wording and sent back with its substitutions
    resolved keeps one copy of the old text in the agent's custom instructions, and that copy does not grow (see
    CommonInstructionStripper).

    Data only: the rules for stripping the texts belong to CommonInstructionStripper.
    """

    # The words the prefix opens with. The network name and a period follow them, then PREFIX_RULES, so the file
    # for a network called coffee_shop starts every agent with
    # "You are part of a team of assistants in coffee_shop." and the rules.
    PREFIX_OPENING: str = "You are part of a team of assistants in"

    # The three lines after the prefix's opening sentence.
    PREFIX_RULES: str = (
        "Only answer inquiries that are directly within your area of expertise.\n"
        "Do not try to help for other matters.\n"
        "Do not mention what you can NOT do. Only mention what you can do."
    )

    # The lines the top-agent template writes inside the front man's own triple-quoted body, ahead of its text.
    FRONT_MAN_LINES: str = (
        "Never express irrelevance unless you have first consulted all your tools.\n"
        "Once you have determined the relevant tools, do not express that to the user, rather,\n"
        "call all the relevant tools and make sure the command is fully serviced and express the end result."
    )

    # The value of the "demo_mode" key a generated network defines when demo mode is on, which the leaf template
    # puts between the prefix and the leaf's own text. It holds no double quote or backslash, so the header can
    # write it as a double-quoted HOCON string as is.
    DEMO_SENTENCE: str = (
        "You are part of a demo system, so when queried, make up a realistic response as if you are actually "
        "grounded in real data or you are operating a real application API or microservice."
    )
